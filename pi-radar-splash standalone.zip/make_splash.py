"""
make_splash.py  —  Pi Radar splash screen installer
Run from the root of the skylight project:  python make_splash.py

What it does
------------
1. Copies Splash.tsx  ->  web/src/display/Splash.tsx
2. Patches Display.tsx to import and render the splash component

Before running
--------------
Copy your logo file into web/public/logo.png:
  mkdir web\\public
  copy path\\to\\TUSKANO_SIDE_FACE_2021.png web\\public\\logo.png
"""

import pathlib, re, shutil, sys

ROOT = pathlib.Path(__file__).parent

# ── 1. Copy Splash.tsx into web/src/display/ ─────────────────────────────────
src_splash = ROOT / "Splash.tsx"
dst_splash = ROOT / "web" / "src" / "display" / "Splash.tsx"

if not src_splash.exists():
    print("ERROR: Splash.tsx not found next to this script.")
    sys.exit(1)

shutil.copy(src_splash, dst_splash)
print(f"Copied Splash.tsx  ->  {dst_splash}")

# ── 2. Patch Display.tsx ──────────────────────────────────────────────────────
dp  = ROOT / "web" / "src" / "display" / "Display.tsx"
if not dp.exists():
    print(f"ERROR: Display.tsx not found at {dp}")
    sys.exit(1)

src = dp.read_text(encoding="utf-8")

# a) Ensure useState is imported from React
if "useState" not in src:
    src, n = re.subn(
        r'import \{ (useEffect[^}]*) \} from "react"',
        lambda m: f'import {{ {m.group(1)}, useState }} from "react"',
        src, count=1,
    )
    print(f"  Added useState to React import ({n} replacement).")
else:
    print("  useState already imported — skipped.")

# b) Add Splash import after useStream import
if "Splash" not in src:
    src = src.replace(
        'import { useStream }',
        'import { Splash } from "./Splash.js";\nimport { useStream }',
    )
    print("  Added Splash import.")
else:
    print("  Splash already imported — skipped.")

# c) Add splashDone state + displayReady after useStream call
if "splashDone" not in src:
    src = src.replace(
        'const { state, conn } = useStream("display");',
        'const { state, conn } = useStream("display");\n'
        '  const [splashDone, setSplashDone] = useState(false);\n'
        '  const displayReady = state.connected;',
    )
    print("  Added splashDone state.")
else:
    print("  splashDone already present — skipped.")

# d) Render Splash as first child of display-root
if "<Splash" not in src:
    src = src.replace(
        '<div className="display-root">',
        '<div className="display-root">\n'
        '      {!splashDone && <Splash ready={displayReady} onDone={() => setSplashDone(true)} />}',
    )
    print("  Added <Splash> to JSX.")
else:
    print("  <Splash> already in JSX — skipped.")

dp.write_text(src, encoding="utf-8")
print(f"Patched  {dp}")

print("\nDone!  Next steps:")
print("  1. pnpm -F web build")
print("  2. Deploy web/dist to Pi as normal")
