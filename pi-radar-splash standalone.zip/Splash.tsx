import { useEffect, useRef, useState } from "react";

const SWEEP_PERIOD    = 3000;
const REVEAL_DURATION = 1800;
const FADE_DURATION   = 600;

const BLIPS = [
  { a: 0.52, r: 0.38, s: 1.0 }, { a: 1.18, r: 0.61, s: 0.7 },
  { a: 2.05, r: 0.44, s: 0.9 }, { a: 2.73, r: 0.72, s: 0.6 },
  { a: 3.41, r: 0.55, s: 0.8 }, { a: 4.20, r: 0.33, s: 1.0 },
  { a: 4.88, r: 0.66, s: 0.5 }, { a: 5.50, r: 0.48, s: 0.7 },
  { a: 0.22, r: 0.80, s: 0.4 }, { a: 1.70, r: 0.28, s: 0.9 },
  { a: 3.90, r: 0.82, s: 0.5 },
] as const;

interface Props {
  ready: boolean;
  onDone: () => void;
}

export function Splash({ ready, onDone }: Props) {
  const canvasRef    = useRef<HTMLCanvasElement>(null);
  const startRef     = useRef(performance.now());
  const rafRef       = useRef<number>(0);
  const timerDoneRef = useRef(false);
  const readyRef     = useRef(false);
  const revealRef    = useRef<number>(0);
  const fadeRef      = useRef<number>(0);

  const [phase, setPhase]                       = useState<"static" | "sweep" | "fading" | "done">("static");
  const [countdown, setCountdown]               = useState(5);
  const [overlayOpacity, setOverlayOpacity]     = useState(1);
  const [containerOpacity, setContainerOpacity] = useState(1);
  const phaseRef = useRef<"static" | "sweep" | "fading" | "done">("static");
  phaseRef.current = phase;

  // Countdown display
  useEffect(() => {
    const iv = setInterval(() => setCountdown(c => Math.max(0, c - 1)), 1000);
    return () => clearInterval(iv);
  }, []);

  // 5-second minimum timer
  useEffect(() => {
    const t = setTimeout(() => {
      timerDoneRef.current = true;
      if (readyRef.current) setPhase("sweep");
    }, 5000);
    return () => clearTimeout(t);
  }, []);

  // Tracker ready signal (passed in as prop from Display)
  useEffect(() => {
    readyRef.current = ready;
    if (ready && timerDoneRef.current) setPhase("sweep");
  }, [ready]);

  // Record sweep start time
  useEffect(() => {
    if (phase === "sweep") revealRef.current = performance.now();
  }, [phase]);

  // Main render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      canvas.width  = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const tick = (now: number) => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const w = canvas.width, h = canvas.height;
      const cx = w / 2, cy = h / 2;
      const maxR = Math.min(w, h) * 0.44;

      ctx.clearRect(0, 0, w, h);

      // Background
      ctx.fillStyle = "#030c06";
      ctx.fillRect(0, 0, w, h);

      // Bearing lines every 30°
      for (let deg = 0; deg < 360; deg += 30) {
        const rad = (deg * Math.PI) / 180;
        ctx.strokeStyle = "rgba(0,220,70,0.12)";
        ctx.lineWidth   = 1;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(rad) * maxR * 1.6, cy + Math.sin(rad) * maxR * 1.6);
        ctx.stroke();
      }

      // Range rings
      [0.25, 0.50, 0.75, 1.0].forEach((f, i) => {
        ctx.strokeStyle = `rgba(0,220,70,${i === 3 ? 0.35 : 0.25})`;
        ctx.lineWidth   = i === 3 ? 1.5 : 1;
        ctx.beginPath();
        ctx.arc(cx, cy, maxR * f, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Sweep trail
      const sweepAngle = (((now - startRef.current) % SWEEP_PERIOD) / SWEEP_PERIOD) * Math.PI * 2 - Math.PI / 2;
      const TRAIL  = Math.PI * 0.55;
      const trailR = maxR * 1.05;
      for (let i = 0; i < 24; i++) {
        const a1 = sweepAngle - TRAIL + (i / 24) * TRAIL;
        const a2 = sweepAngle - TRAIL + ((i + 1) / 24) * TRAIL;
        ctx.fillStyle = `rgba(0,220,70,${(i / 24) * 0.22})`;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, trailR, a1, a2);
        ctx.closePath();
        ctx.fill();
      }

      // Sweep line
      const ex = cx + Math.cos(sweepAngle) * trailR;
      const ey = cy + Math.sin(sweepAngle) * trailR;
      const lg  = ctx.createLinearGradient(cx, cy, ex, ey);
      lg.addColorStop(0,   "rgba(0,255,80,0)");
      lg.addColorStop(0.4, "rgba(0,255,80,0.3)");
      lg.addColorStop(1,   "rgba(0,255,80,1)");
      ctx.strokeStyle = lg;
      ctx.lineWidth   = 2;
      ctx.shadowColor = "rgba(0,255,80,0.9)";
      ctx.shadowBlur  = 10;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(ex, ey);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Blips
      BLIPS.forEach(b => {
        const bx   = cx + Math.cos(b.a) * maxR * b.r;
        const by   = cy + Math.sin(b.a) * maxR * b.r;
        const diff = ((b.a - sweepAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
        const alpha = (0.25 + Math.max(0, 1 - diff / TRAIL) * 0.75) * b.s;
        ctx.shadowColor = "rgba(0,255,80,0.8)";
        ctx.shadowBlur  = 6;
        ctx.fillStyle   = `rgba(0,255,100,${alpha})`;
        ctx.beginPath();
        ctx.arc(bx, by, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Centre dot
      ctx.shadowColor = "rgba(0,255,80,1)";
      ctx.shadowBlur  = 12;
      ctx.fillStyle   = "rgba(0,255,100,0.9)";
      ctx.beginPath();
      ctx.arc(cx, cy, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Reveal wipe
      if (phaseRef.current === "sweep") {
        const t         = Math.min((now - revealRef.current) / REVEAL_DURATION, 1);
        const wipeAngle = t * Math.PI * 2;
        const bigR      = Math.sqrt(cx * cx + cy * cy) * 1.3;

        ctx.globalCompositeOperation = "source-over";
        ctx.fillStyle = "rgba(3,12,6,0.92)";
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        const startA = -Math.PI / 2 + wipeAngle;
        ctx.arc(cx, cy, bigR, startA, startA + (Math.PI * 2 - wipeAngle), false);
        ctx.lineTo(cx, cy);
        ctx.closePath();
        ctx.fill();

        const wa = -Math.PI / 2 + wipeAngle;
        const wx = cx + Math.cos(wa) * bigR;
        const wy = cy + Math.sin(wa) * bigR;
        const wg = ctx.createLinearGradient(cx, cy, wx, wy);
        wg.addColorStop(0,   "rgba(0,255,80,0)");
        wg.addColorStop(0.5, "rgba(0,255,80,0.5)");
        wg.addColorStop(1,   "rgba(0,255,80,1)");
        ctx.strokeStyle = wg;
        ctx.lineWidth   = 3;
        ctx.shadowColor = "rgba(0,255,80,1)";
        ctx.shadowBlur  = 16;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(wx, wy);
        ctx.stroke();
        ctx.shadowBlur = 0;

        setOverlayOpacity(1 - t);
        if (t >= 1) { setPhase("fading"); fadeRef.current = now; }
      }

      // Fade-out dissolve into display
      if (phaseRef.current === "fading") {
        const ft = Math.min((now - fadeRef.current) / FADE_DURATION, 1);
        setContainerOpacity(1 - ft);
        if (ft >= 1) { setPhase("done"); onDone(); return; }
      }

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
    };
  }, [onDone]);

  if (phase === "done") return null;

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 50, fontFamily: "monospace", overflow: "hidden", opacity: containerOpacity }}>
      {/* Radar canvas */}
      <canvas
        ref={canvasRef}
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
      />

      {/* Logo — bottom left, screen blend dissolves black background */}
      <img
        src="/logo.png"
        alt="Fuzz Beard Industries"
        style={{
          position: "absolute", bottom: 24, left: 28,
          width: 220,
          opacity: overlayOpacity * 0.85,
          mixBlendMode: "screen",
          pointerEvents: "none",
        }}
      />

      {/* Centre text */}
      <div style={{
        position: "absolute", inset: 0,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        opacity: overlayOpacity,
        pointerEvents: "none",
      }}>
        <div style={{ color: "#00dd50", fontSize: 26, fontWeight: "bold", letterSpacing: 4, textShadow: "0 0 12px rgba(0,255,80,0.7)" }}>
          PI RADAR
        </div>
        <div style={{ color: "rgba(0,200,70,0.7)", fontSize: 13, letterSpacing: 2, marginTop: 8 }}>
          FLIGHT MONITOR · FUZZ BEARD INDUSTRIES
        </div>
        <div style={{ color: "rgba(0,160,50,0.45)", fontSize: 10, letterSpacing: 1, marginTop: 6 }}>
          BASED ON THE SKYLIGHT PROJECT BY CPACZEK
        </div>
        <div style={{ marginTop: 32, color: "rgba(0,220,70,0.5)", fontSize: 11, letterSpacing: 2 }}>
          {countdown > 0 ? `INITIALISING  ${countdown}` : "CONNECTING TO FEED ···"}
        </div>
      </div>
    </div>
  );
}
